import streamlit as st
import pandas as pd
import random
from datetime import datetime
from collections import Counter

st.set_page_config(page_title="Network Security & Firewall Monitor", page_icon="🛡️", layout="wide")

if "logs" not in st.session_state:
    st.session_state.logs = []
if "rules" not in st.session_state:
    st.session_state.rules = [
        {"name": "Allow HTTP", "src": "*", "dst": "*", "port": 80, "protocol": "TCP", "action": "ALLOW"},
        {"name": "Allow HTTPS", "src": "*", "dst": "*", "port": 443, "protocol": "TCP", "action": "ALLOW"},
        {"name": "Allow DNS", "src": "*", "dst": "*", "port": 53, "protocol": "UDP", "action": "ALLOW"},
        {"name": "Block Telnet", "src": "*", "dst": "*", "port": 23, "protocol": "TCP", "action": "BLOCK"},
    ]

st.title("🛡️ Network Security and Firewall Monitoring System")
st.caption("Educational packet-filtering simulation — generated traffic only; does not capture or block real network packets.")

def evaluate_packet(packet):
    # Explicit BLOCK rules take priority; otherwise an explicit ALLOW rule is required.
    matches = []
    for rule in st.session_state.rules:
        if (rule["src"] == "*" or rule["src"] == packet["Source IP"]) and \
           (rule["dst"] == "*" or rule["dst"] == packet["Destination IP"]) and \
           int(rule["port"]) == int(packet["Port"]) and rule["protocol"] == packet["Protocol"]:
            matches.append(rule)
    block = next((r for r in matches if r["action"] == "BLOCK"), None)
    allow = next((r for r in matches if r["action"] == "ALLOW"), None)
    if block:
        return "BLOCKED", f'Blocked by: {block["name"]}'
    if allow:
        return "ALLOWED", f'Allowed by: {allow["name"]}'
    return "BLOCKED", "No matching allow rule (default deny)"

def make_packet():
    sources = ["192.168.1.10", "192.168.1.25", "10.0.0.8", "203.0.113.45", "198.51.100.22"]
    destinations = ["192.168.1.1", "192.168.1.100", "10.0.0.2"]
    options = [(80, "TCP"), (443, "TCP"), (53, "UDP"), (22, "TCP"), (23, "TCP"), (3389, "TCP"), (8080, "TCP")]
    port, proto = random.choice(options)
    src = random.choice(sources)
    suspicious = port in [23, 3389] or src in ["203.0.113.45", "198.51.100.22"]
    return {
        "Time": datetime.now().strftime("%H:%M:%S"),
        "Source IP": src,
        "Destination IP": random.choice(destinations),
        "Port": port,
        "Protocol": proto,
        "Traffic Type": random.choice(["Incoming", "Outgoing"]),
        "Suspicious Activity": "Yes" if suspicious else "No"
    }

def add_packet(packet):
    status, reason = evaluate_packet(packet)
    row = dict(packet)
    row["Access Status"] = status
    row["Firewall Decision"] = reason
    row["Security Alert"] = "⚠️ Suspicious activity" if packet["Suspicious Activity"] == "Yes" else ("🚫 Access blocked" if status == "BLOCKED" else "None")
    st.session_state.logs.insert(0, row)

tabs = st.tabs(["📊 Dashboard", "🧱 Firewall Rules", "📡 Traffic Simulator", "📜 Security Logs"])

with tabs[0]:
    logs = pd.DataFrame(st.session_state.logs)
    total = len(logs)
    allowed = int((logs["Access Status"] == "ALLOWED").sum()) if total else 0
    blocked = int((logs["Access Status"] == "BLOCKED").sum()) if total else 0
    suspicious = int((logs["Suspicious Activity"] == "Yes").sum()) if total else 0
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Total Packets", total)
    c2.metric("Allowed", allowed)
    c3.metric("Blocked", blocked)
    c4.metric("Suspicious", suspicious)
    if total:
        left,right = st.columns(2)
        with left:
            st.subheader("Access status")
            st.bar_chart(logs["Access Status"].value_counts())
        with right:
            st.subheader("Traffic by protocol")
            st.bar_chart(logs["Protocol"].value_counts())
        st.subheader("Recent network activity")
        st.dataframe(logs.head(12), use_container_width=True, hide_index=True)
    else:
        st.info("No traffic generated yet. Open the Traffic Simulator tab and generate packets.")

with tabs[1]:
    st.subheader("Configure firewall rules")
    st.write("A packet is allowed only when it matches an ALLOW rule. BLOCK rules take priority. Unmatched traffic is blocked by default.")
    with st.form("rule_form"):
        a,b,c = st.columns(3)
        name = a.text_input("Rule name", "Allow SSH from trusted host")
        src = b.text_input("Source IP (* for any)", "*")
        dst = c.text_input("Destination IP (* for any)", "*")
        d,e,f = st.columns(3)
        port = d.number_input("Port number", min_value=1, max_value=65535, value=22)
        protocol = e.selectbox("Protocol", ["TCP", "UDP"])
        action = f.selectbox("Action", ["ALLOW", "BLOCK"])
        submitted = st.form_submit_button("Add firewall rule")
        if submitted:
            st.session_state.rules.append({"name": name, "src": src.strip() or "*", "dst": dst.strip() or "*",
                                           "port": int(port), "protocol": protocol, "action": action})
            st.success("Firewall rule added.")
    st.subheader("Current rules")
    rules_df = pd.DataFrame(st.session_state.rules)
    st.dataframe(rules_df, use_container_width=True, hide_index=True)
    if st.button("Restore default rules"):
        st.session_state.rules = [
            {"name": "Allow HTTP", "src": "*", "dst": "*", "port": 80, "protocol": "TCP", "action": "ALLOW"},
            {"name": "Allow HTTPS", "src": "*", "dst": "*", "port": 443, "protocol": "TCP", "action": "ALLOW"},
            {"name": "Allow DNS", "src": "*", "dst": "*", "port": 53, "protocol": "UDP", "action": "ALLOW"},
            {"name": "Block Telnet", "src": "*", "dst": "*", "port": 23, "protocol": "TCP", "action": "BLOCK"},
        ]
        st.rerun()

with tabs[2]:
    st.subheader("Generate simulated network packets")
    st.write("Create sample incoming/outgoing traffic and observe the firewall decision.")
    x,y = st.columns(2)
    count = x.slider("Number of packets to generate", 1, 50, 10)
    if y.button("▶ Generate traffic", type="primary"):
        for _ in range(count):
            add_packet(make_packet())
        st.success(f"{count} simulated packets processed.")
    st.markdown("**Manual packet test**")
    with st.form("manual_packet"):
        p1,p2 = st.columns(2)
        sip = p1.text_input("Source IP", "192.168.1.10")
        dip = p2.text_input("Destination IP", "192.168.1.1")
        p3,p4,p5 = st.columns(3)
        prt = p3.number_input("Destination port", 1, 65535, 443)
        proto = p4.selectbox("Protocol", ["TCP", "UDP"])
        direction = p5.selectbox("Traffic type", ["Incoming", "Outgoing"])
        if st.form_submit_button("Test packet"):
            packet = {"Time": datetime.now().strftime("%H:%M:%S"), "Source IP": sip, "Destination IP": dip,
                      "Port": int(prt), "Protocol": proto, "Traffic Type": direction,
                      "Suspicious Activity": "Yes" if int(prt) in [23, 3389] else "No"}
            add_packet(packet)
            st.success(f'Firewall result: {st.session_state.logs[0]["Access Status"]} — {st.session_state.logs[0]["Firewall Decision"]}')

with tabs[3]:
    st.subheader("Security event log")
    logs = pd.DataFrame(st.session_state.logs)
    if len(logs):
        filter_choice = st.selectbox("Show events", ["All", "Allowed", "Blocked", "Suspicious"])
        view = logs
        if filter_choice == "Allowed":
            view = logs[logs["Access Status"] == "ALLOWED"]
        elif filter_choice == "Blocked":
            view = logs[logs["Access Status"] == "BLOCKED"]
        elif filter_choice == "Suspicious":
            view = logs[logs["Suspicious Activity"] == "Yes"]
        st.dataframe(view, use_container_width=True, hide_index=True)
        st.download_button("Download security log as CSV", logs.to_csv(index=False), "firewall_security_log.csv", "text/csv")
        if st.button("Clear all logs"):
            st.session_state.logs = []
            st.rerun()
    else:
        st.info("Security logs will appear here after packets are generated.")
