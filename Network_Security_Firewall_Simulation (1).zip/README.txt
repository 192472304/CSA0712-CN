# Network Security and Firewall Monitoring System

## Requirements
- Python 3.9 or later
- Internet connection for the first-time package installation

## Run in VS Code / terminal
1. Extract this ZIP file.
2. Open the extracted folder in VS Code.
3. Open Terminal in that folder.
4. Install packages:

   pip install -r requirements.txt

5. Start the dashboard:

   streamlit run app.py

6. Open the local address shown in the terminal (usually http://localhost:8501).

## Demonstration
- Open **Traffic Simulator** and generate sample packets.
- Open **Dashboard** to view allowed, blocked and suspicious packet counts.
- Open **Firewall Rules** to add a rule, such as allowing TCP port 22.
- Return to **Traffic Simulator** and test a packet matching that rule.
- Open **Security Logs** to inspect and download the events.

## Important
This is an educational simulation. It generates synthetic packet records and demonstrates rule-based decisions. It does not capture, inspect, or block traffic on a real network.
